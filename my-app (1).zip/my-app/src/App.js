/* global fetch */
import React, {Component} from 'react';
// import {useState} from 'react';
import logo from './logo.svg';
import './App.css';
import {ModalHeader, Modal, ModalBody, ModalFooter, Table, Button, Form, FormGroup, Label, Input} from 'reactstrap';
import axios from 'axios';
//  const header = new Headers();
//header.append('Access-Control-Allow-Origin', '*');
class App extends Component
{ 
    constructor(props) {
        super(props);
        this.state =  
        { 
        InterceptDataloadRules: [],
        newRuleModal: true, 
        modal: props.initialModalState,
        fade: true,
        newRuleData: {id:'', type:'', commentVal:'', status:'', BBS:'',createdDate:''}
        };
        this.toggle = this.toggle.bind(this);
    }
    toggle() {
        this.setState({
            modal: !this.state.modal,
            fade: !this.state.fade

        });
    };
    toggleNewRuleModal() {
        // This sets the state of modal and setModal to false.
        //const [newRuleModal, setModal ] = useState(false);
        // setModal(!newRuleModal);
        this.setState( {newRuleModal: true} );
        
        alert("setting newRuleModel value is:");
        alert(this.newRuleModal);
        
    };
    addNewRule() {
        alert("going to the web service to ADD the data with AXIOS");
 axios.post('http://localhost:8080/InterceptDataloadRules',this.state.newRuleData).then((response) =>
        {      
            alert(response.data);
        let {InterceptDataloadRules} = this.state;
       // InterceptDataloadRules.push(response.data);
        this.setState( { InterceptDataloadRules, newRuleModal:false,
            newRuleData: {
                id: '', type: '', commentVal:'', status:'', BBS:'',createdDate:''}
                           } );
         });  
       
   // InterceptDataloadRules.push(response.data);
    };
    componentDidMount() 
    {
      //  const header = new Headers();
       // header.append('Access-Control-Allow-Origin', '*');
      //  alert("Calling Fetch method inside React app to get data from Web services/table");
    //  axios.get('http://localhost:8080/InterceptDataloadRules/').then( (response) => 
      
       fetch('http://localhost:8080/InterceptDataloadRules/').then(response => 
        response.json()).then( (data) => 
       {           
                  //  alert(data);
                    this.setState ( {InterceptDataloadRules:data  });                  
       } )
                .catch( ( error) => {
                         alert("Error connecting");
                         
                         this.setState({ error: error.message
                                         }); 
        });
    };
 render() {
      let rules = this.state.InterceptDataloadRules.map( (rule) => 
      { return (
             <tr key = {rule.id}>
             <td> {rule.id} </td>
                <td> {rule.type} </td>
                <td> {rule.commentVal} </td>
                <td> {rule.status} </td>
                <td> {rule.bbs} </td>
                <td> {rule.createdDate} </td> 
                <td><Button color="success" size="sm" className="mr-2"> Edit </Button >
                <Button color="danger" size="sm" className="mr-2"> Delete </Button>
                </td>
            </tr> 
          );
      } );
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" /> 
        <h1>Intercept Dataload Rules </h1>
   <Button color="danger" onClick={this.toggle}>TOGGLE</Button>
                <Modal isOpen={this.state.modal} toggle={this.toggle}
                       fade={this.state.fade}
                       className={this.props.className}>
                    <ModalHeader toggle={this.toggle}>Modal title</ModalHeader>
                    <ModalBody>Hi</ModalBody>
                </Modal>
        <Button color ="primary" onClick ={this.toggle}> Add New Rule </Button>
        <Modal isOpen = {this.state.modal} toggle ={this.toggle}>
        <ModalHeader toggle={this.toggle}> Add a New Rule </ModalHeader>
        <ModalBody>
        <Form>
        <FormGroup>
            <Label for ="id"> ID: </Label>
            <Input id="id" value= {this.state.newRuleData.id}
            onChange = { (e)  => { 
            let { newRuleData } = this.state;
            newRuleData.id = e.target.value;
            this.setState( {newRuleData} );
            } } /> 
            <Label for="Type"> Type: </Label>
            <Input type="text"
                name="Type" id="Type" placeholder="Type placeholder"/>
            <Label for="Comment"> Comment: </Label>
            <Input type="text"
                name="Comment" id="Type" placeholder="Comment placeholder"/>
            <Label for="Status"> Status: </Label>  
            <Input type="text"
                name="Status" id="Type" placeholder="Comment placeholder"/> 
            <Label for="BBS"> BBS: </Label>  
            <Input type="text" 
                name="bbs" id="Type" placeholder="BBS placeholder"/>   
            <Label for="Created Date"> Created Date: </Label>  
            <Input type="text"
                name="Created Date" id="Type" placeholder="placeholder"/>  
        </FormGroup>
        </Form>  
        </ModalBody>
        <ModalFooter>
          <Button color="primary" onClick={this.addNewRule.bind(this)}>Add New Rule</Button>{' '}
          <Button color="secondary" onClick={this.toggle}>Cancel</Button>
        </ModalFooter>
        </Modal> 
        <Table bordered>
        <thead>
        <tr>
        <td>ID#</td>
        <td>Type</td>
        <td>Comment</td>
        <td>Status </td>
        <td>BBS</td>
        <td>CreatedDate</td> 
        <td>Actions</td>
        </tr> 
        </thead>
         <tbody>           
         {rules}           
        </tbody>
        </Table>   
        <a className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer" >
          Learn React
        </a>
        </header>
    </div>
    );
}
};
export default App;  